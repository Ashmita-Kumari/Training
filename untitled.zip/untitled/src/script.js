document.addEventListener('DOMContentLoaded', () => {

    const hamburger = document.querySelector('.hamburger');

    const mobileMenu = document.querySelector('.mobile-menu');

    hamburger.addEventListener('click', () => {

        mobileMenu.classList.toggle('active');

    });

    // Close mobile menu when a link is clicked

    const navLinks = document.querySelectorAll('.mobile-menu a');

    navLinks.forEach(link => {

        link.addEventListener('click', () => {

            mobileMenu.classList.remove('active');

        });

    });

});